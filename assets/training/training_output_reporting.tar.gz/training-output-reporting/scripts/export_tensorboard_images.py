#!/usr/bin/env python3
"""Export the latest ranked qualitative images from TensorBoard events."""

from __future__ import annotations

import argparse
import csv
import io
import re
from pathlib import Path

from PIL import Image
from tensorboard.backend.event_processing.event_accumulator import EventAccumulator

TAG_PATTERN = re.compile(r"^qualitative/(best|worst)/(\d+)_?(.*)$")


def safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("._") or "image"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--logdir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    directories = sorted({p.parent for p in args.logdir.resolve().rglob("events.out.tfevents.*") if p.is_file()})
    if not directories:
        raise SystemExit(f"no TensorBoard event files found under {args.logdir}")
    latest: dict[str, object] = {}
    for directory in directories:
        accumulator = EventAccumulator(str(directory), size_guidance={"images": 0})
        accumulator.Reload()
        for tag in accumulator.Tags().get("images", []):
            if not TAG_PATTERN.match(tag):
                continue
            for event in accumulator.Images(tag):
                old = latest.get(tag)
                if old is None or (event.step, event.wall_time) >= (old.step, old.wall_time):
                    latest[tag] = event
    if not latest:
        raise SystemExit("no qualitative/best or qualitative/worst TensorBoard image tags found")
    output = args.output_dir.resolve()
    rows: list[dict[str, object]] = []
    for tag in sorted(latest):
        match = TAG_PATTERN.match(tag)
        assert match is not None
        group, rank_text, image_id = match.groups()
        event = latest[tag]
        image = Image.open(io.BytesIO(event.encoded_image_string)).convert("RGB")
        relative = Path(group) / f"{int(rank_text):02d}_{safe_name(image_id)}.png"
        destination = output / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        image.save(destination)
        rows.append({"group": group, "rank": int(rank_text), "tag": tag, "step": event.step,
                     "width": image.width, "height": image.height, "path": relative.as_posix()})
    output.mkdir(parents=True, exist_ok=True)
    with (output / "manifest.csv").open("w", newline="", encoding="utf-8") as handle:
        fields = ["group", "rank", "tag", "step", "width", "height", "path"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(sorted(rows, key=lambda row: (str(row["group"]), int(row["rank"]))))
    print(f"exported {len(rows)} ranked images")


if __name__ == "__main__":
    main()
