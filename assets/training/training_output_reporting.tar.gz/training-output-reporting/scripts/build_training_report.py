#!/usr/bin/env python3
"""Build a portable loss curve, summary JSON, and static training reports."""

from __future__ import annotations

import argparse
import csv
import html
import json
import math
import os
import re
import shutil
import tempfile
from pathlib import Path


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.is_file():
        raise SystemExit(f"required CSV is missing: {path}")
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def finite(row: dict[str, str], key: str) -> float | None:
    try:
        value = float(row.get(key, ""))
    except (TypeError, ValueError):
        return None
    return value if math.isfinite(value) else None


def loss_curve(rows: list[dict[str, str]], destination: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    from matplotlib import pyplot as plt

    usable = [(finite(r, "epoch"), finite(r, "train_loss"), finite(r, "val_loss")) for r in rows]
    usable = [(e, t, v) for e, t, v in usable if e is not None and t is not None and v is not None]
    if not usable:
        raise SystemExit("epochs.csv has no finite train/validation loss rows")
    destination.parent.mkdir(parents=True, exist_ok=True)
    figure, axis = plt.subplots(figsize=(8, 5))
    axis.plot([x[0] for x in usable], [x[1] for x in usable], marker="o", label="Train")
    axis.plot([x[0] for x in usable], [x[2] for x in usable], marker="o", label="Validation")
    axis.set(xlabel="Epoch", ylabel="Loss", title="Training and validation loss")
    axis.grid(alpha=0.3)
    axis.legend()
    figure.tight_layout()
    figure.savefig(destination, dpi=150)
    plt.close(figure)


def copy_ranked_images(run: Path, manifest: list[dict[str, str]], reports: Path) -> dict[str, list[dict[str, str]]]:
    source_root = run / "tensorboard" / "images"
    groups: dict[str, list[dict[str, str]]] = {"best": [], "worst": []}
    for row in manifest:
        group = row.get("group", "")
        if group not in groups:
            continue
        relative = Path(row.get("path", ""))
        source = (source_root / relative).resolve()
        if source_root.resolve() not in source.parents or not source.is_file():
            raise SystemExit(f"unsafe or missing manifest image: {relative}")
        target = reports / "assets" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        copied = dict(row)
        copied["report_path"] = (Path("assets") / relative).as_posix()
        groups[group].append(copied)
    for group in groups:
        groups[group].sort(key=lambda row: int(row.get("rank", "999999")))
        if not groups[group]:
            raise SystemExit(f"manifest has no {group} images")
    return groups


def page(title: str, heading: str, rows: list[dict[str, str]], *, include_curve: bool = False) -> str:
    cards = "\n".join(
        f'<figure><img src="{html.escape(row["report_path"])}" alt="{html.escape(row.get("tag", "composite"))}">'
        f'<figcaption>Rank {html.escape(row.get("rank", ""))} · step {html.escape(row.get("step", ""))}</figcaption></figure>'
        for row in rows[:20]
    )
    curve = '<section><h2>Loss curve</h2><img class="curve" src="assets/loss_curve.png" alt="Training and validation loss curve"></section>' if include_curve else ""
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(title)}</title>
<style>body{{font-family:system-ui,sans-serif;max-width:1200px;margin:auto;padding:24px;background:#f6f7f9;color:#17202a}}nav a{{margin-right:16px}}section{{margin:28px 0}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(360px,1fr));gap:18px}}figure{{margin:0;background:white;padding:12px;border-radius:8px;box-shadow:0 1px 5px #ccd}}img{{max-width:100%;height:auto}}.curve{{background:white;padding:8px}}figcaption{{margin-top:8px}}</style></head>
<body><h1>{html.escape(heading)}</h1><nav><a href="index.html">Overview</a><a href="best_20.html">Best 20</a><a href="worst_20.html">Worst 20</a></nav>{curve}<section><h2>Input · GT · Prediction · Overlay</h2><div class="grid">{cards}</div></section></body></html>"""


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    run = args.run_dir.resolve()
    metrics = run / "metrics"
    images = run / "tensorboard" / "images"
    reports = run / "reports"
    epochs = read_csv(metrics / "epochs.csv")
    validation = read_csv(metrics / "per_image_validation.csv")
    manifest = read_csv(images / "manifest.csv")
    outer_path = metrics / "outer_test_metrics.json"
    outer = (json.loads(outer_path.read_text(encoding="utf-8"))
             if outer_path.is_file() else {"scope": "outer_test_skipped"})
    missing_accuracy = [row for row in validation if finite(row, "accuracy") is None]
    if missing_accuracy:
        raise SystemExit("per_image_validation.csv has missing or non-finite accuracy values")
    rankable = [row for row in validation if finite(row, "f1") is not None]
    if not rankable:
        raise SystemExit("per_image_validation.csv has no finite F1 values")
    with tempfile.TemporaryDirectory(prefix="crackseg-matplotlib-") as cache:
        os.environ.setdefault("MPLCONFIGDIR", cache)
        loss_curve(epochs, images / "loss_curve.png")
    reports.mkdir(parents=True, exist_ok=True)
    (reports / "assets").mkdir(parents=True, exist_ok=True)
    shutil.copy2(images / "loss_curve.png", reports / "assets" / "loss_curve.png")
    groups = copy_ranked_images(run, manifest, reports)
    selected_epoch = outer.get("selected_epoch")
    if selected_epoch is None:
        usable_losses = [row for row in epochs if finite(row, "val_loss") is not None]
        if not usable_losses:
            raise SystemExit("epochs.csv has no finite validation loss for checkpoint selection")
        best_epoch = min(usable_losses, key=lambda row: finite(row, "val_loss"))
        selected_epoch = int(float(best_epoch["epoch"]))
    else:
        selected_epoch = int(selected_epoch)
        matches = [row for row in epochs if int(float(row["epoch"])) == selected_epoch]
        if len(matches) != 1:
            raise SystemExit(f"selected epoch {selected_epoch} is absent or duplicated in epochs.csv")
        best_epoch = matches[0]
    summary = {
        "run_dir": str(run), "epoch_count": len(epochs), "validation_image_count": len(validation),
        "selected_epoch": selected_epoch, "selected_validation_metrics": best_epoch,
        "outer_test_metrics": outer, "selection_policy": "validation_only_outer_test_excluded",
        "reporting": {"best_images": len(groups["best"]), "worst_images": len(groups["worst"]), "panel_order": ["input", "gt", "prediction", "overlay"]},
    }
    metrics.mkdir(parents=True, exist_ok=True)
    (metrics / "experiment_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    (reports / "index.html").write_text(page("Training report", "Training report", groups["best"][:4] + groups["worst"][:4], include_curve=True), encoding="utf-8")
    (reports / "best_20.html").write_text(page("Best validation examples", "Best validation examples", groups["best"]), encoding="utf-8")
    (reports / "worst_20.html").write_text(page("Worst validation examples", "Worst validation examples", groups["worst"]), encoding="utf-8")
    for report in reports.glob("*.html"):
        contents = report.read_text(encoding="utf-8")
        for relative in set(re.findall(r'src="([^"]+)"', contents)):
            if not (reports / relative).is_file():
                raise SystemExit(f"broken image path in {report.name}: {relative}")
    print(f"built reports in {reports}")


if __name__ == "__main__":
    main()
