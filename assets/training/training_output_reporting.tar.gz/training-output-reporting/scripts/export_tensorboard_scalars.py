#!/usr/bin/env python3
"""Export TensorBoard scalars to long-form and canonical epoch CSV files."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

from tensorboard.backend.event_processing.event_accumulator import EventAccumulator

TAGS = {
    "loss/train": "train_loss", "loss/validation": "val_loss",
    "metrics/f1": "f1", "metrics/precision": "precision",
    "metrics/recall": "recall", "metrics/iou": "iou",
    "metrics/accuracy": "accuracy",
    "optimizer/lr": "learning_rate",
}


def load_scalars(logdir: Path) -> list[dict[str, object]]:
    directories = sorted({p.parent for p in logdir.rglob("events.out.tfevents.*") if p.is_file()})
    if not directories:
        raise SystemExit(f"no TensorBoard event files found under {logdir}")
    latest: dict[tuple[str, int], dict[str, object]] = {}
    for directory in directories:
        accumulator = EventAccumulator(str(directory), size_guidance={"scalars": 0})
        accumulator.Reload()
        for tag in accumulator.Tags().get("scalars", []):
            for event in accumulator.Scalars(tag):
                row = {"step": event.step, "wall_time": event.wall_time, "tag": tag, "value": event.value}
                key = (tag, event.step)
                if key not in latest or event.wall_time >= float(latest[key]["wall_time"]):
                    latest[key] = row
    return sorted(latest.values(), key=lambda row: (int(row["step"]), str(row["tag"])))


def write_csv(path: Path, fields: list[str], rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--logdir", type=Path, required=True)
    parser.add_argument("--scalars-out", type=Path, required=True)
    parser.add_argument("--epochs-out", type=Path, required=True)
    args = parser.parse_args()
    rows = load_scalars(args.logdir.resolve())
    missing = sorted(set(TAGS) - {str(row["tag"]) for row in rows})
    if missing:
        raise SystemExit(f"missing required TensorBoard scalar tags: {', '.join(missing)}")
    write_csv(args.scalars_out, ["step", "wall_time", "tag", "value"], rows)
    by_step: dict[int, dict[str, object]] = {}
    for row in rows:
        tag = str(row["tag"])
        if tag in TAGS:
            step = int(row["step"])
            by_step.setdefault(step, {"epoch": step})[TAGS[tag]] = row["value"]
    fields = ["epoch", "train_loss", "val_loss", "f1", "precision", "recall", "iou", "accuracy", "learning_rate"]
    complete = [by_step[s] for s in sorted(by_step) if all(f in by_step[s] for f in fields)]
    if not complete:
        raise SystemExit("no epoch has all required canonical scalar values")
    write_csv(args.epochs_out, fields, complete)
    print(f"exported {len(rows)} scalars and {len(complete)} epochs")


if __name__ == "__main__":
    main()
