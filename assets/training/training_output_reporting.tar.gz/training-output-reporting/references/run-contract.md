# Run output contract

## Layout

```text
<project_root>/runs/<experiment_id>/
  info/                         shared metadata; legacy imports under info/legacy/
  <k>fold/<expert>/fold<index>/
    config/                     configuration, split hashes, environment metadata
    logs/
    tensorboard/images/{loss_curve.png,manifest.csv,best/*.png,worst/*.png}
    metrics/{epochs.csv,tensorboard_scalars.csv,per_image_validation.csv,outer_test_metrics.json,experiment_summary.json}
    artifacts/checkpoints/{best.pt,last.pt}
    artifacts/qualitative/<image-id>/{input,gt,prediction,overlay}.png
    reports/{index.html,best_20.html,worst_20.html}
```

Keep generated runs ignored by Git unless the user explicitly approves versioning a compact report.

## Schemas

Required scalar tags are `loss/train`, `loss/validation`, `metrics/f1`, `metrics/precision`, `metrics/recall`, `metrics/iou`, `metrics/accuracy`, and `optimizer/lr`.

`metrics/epochs.csv` columns are `epoch,train_loss,val_loss,f1,precision,recall,iou,accuracy,learning_rate`. `metrics/tensorboard_scalars.csv` columns are `step,wall_time,tag,value`.

Ranked image tags use `qualitative/best/<rank>_<id>` and `qualitative/worst/<rank>_<id>`. Export the most recent event for each tag. `manifest.csv` columns are `group,rank,tag,step,width,height,path`; paths are relative to the image output directory.

`per_image_validation.csv` must identify each validation image, include finite validation metrics (including `f1` and `accuracy`), and contain relative paths to input, GT, prediction, and overlay. Preserve every validation example; HTML pages show up to 20 best and worst rows ranked by finite `f1`.

## Selection boundary

Select checkpoints and thresholds only from training/validation information. Write outer-test results after selection and label them as excluded from selection. When an approved run explicitly skips outer testing, record `outer_test_skipped` in the summary instead. Missing required artifacts, empty rankable validation rows, unsafe paths outside the run directory, or broken report image links are completion failures.
