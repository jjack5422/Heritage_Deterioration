---
name: training-output-reporting
description: Export and validate durable TensorBoard metrics, ranked qualitative images, and static HTML reports after an approved computer-vision training or artifact-producing evaluation run.
---

# Training Output Reporting

Use this skill only after the repository's experiment and output-path approval gates have passed. It does not authorize training, evaluation, package installation, or changes to experiment selection logic.

## Workflow

1. Read [references/run-contract.md](references/run-contract.md) before integrating or validating a run.
2. Confirm the run belongs under the owning project's `runs/<experiment_id>/<k>fold/<expert>/fold<index>/` tree and that checkpoint selection used validation data, never outer-test results.
3. Require the canonical TensorBoard scalar tags—including `metrics/accuracy`—and durable configuration, split hashes, environment metadata, checkpoints, validation-image metrics, and outer-test metrics described by the contract.
4. After writers are flushed and closed, run the bundled scripts with the repository-approved Python executable:

   ```text
   python scripts/export_tensorboard_scalars.py --logdir RUN/tensorboard --scalars-out RUN/metrics/tensorboard_scalars.csv --epochs-out RUN/metrics/epochs.csv
   python scripts/export_tensorboard_images.py --logdir RUN/tensorboard --output-dir RUN/tensorboard/images
   python scripts/build_training_report.py --run-dir RUN
   ```

5. Verify every required output exists. Open `loss_curve.png` and representative Best/Worst composites locally. The composite order is Input, GT, Prediction, Overlay.
6. Report clickable paths to the run folder, loss curve, representative composites, and three HTML reports. State missing or malformed inputs explicitly; do not claim a run is complete when required artifacts are absent.

The scripts create derived files only. Do not hand-edit their CSV, PNG, JSON, or HTML outputs. Do not launch TensorBoard unless the user asks.
