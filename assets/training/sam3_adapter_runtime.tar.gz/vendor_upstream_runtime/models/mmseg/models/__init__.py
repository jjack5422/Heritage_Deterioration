"""Minimal model namespace; the experiment imports only ``models.sam``."""
