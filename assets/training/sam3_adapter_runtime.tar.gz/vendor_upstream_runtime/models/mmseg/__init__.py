"""Minimal package marker for the SAM decoder subset used by SAM3-Adapter."""
